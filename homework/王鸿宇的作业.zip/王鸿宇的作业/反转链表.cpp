class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode *p=head;
       if(head&&head->next) head=head->next;
       else return head;
        ListNode *q=head;
        p->next=NULL;
        while(head)
        {
            head=head->next;
            q->next=p;
            p=q;
            q=head;
        }
       return p;
    }
};
