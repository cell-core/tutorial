class Solution {
public:
    ListNode* removeNthFromEnd(ListNode* head, int n) {
        int num = 0;
        ListNode* q = head;
        ListNode* p = head;
        ListNode* x = head;

        while (x != NULL)
        {
            num++;
            x = x->next;
        }
        if (num - n == 0) {
            return head->next;
        }

        for (int i = 0; i < num - n; i++) {
            q = p;
            p = p->next;
        }

        if (q->next)
        {
            q->next = q->next->next;
        }

        return head;

    }
}
