class Solution {
public:
    bool hasCycle(ListNode *head) {
     ListNode * fast = head;
     ListNode * low = head;
     while(fast&&fast->next)
     {
         fast = fast->next->next;
         low = low->next;
         if(low==fast)
         {
             return true;
         }
     }
     return false;
    }
};
