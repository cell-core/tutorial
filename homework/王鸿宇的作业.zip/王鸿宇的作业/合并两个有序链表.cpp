class Solution {
public:
    ListNode* mergeTwoLists(ListNode* list1, ListNode* list2) {
        ListNode* p=new ListNode;
        ListNode* q=new ListNode;
        if(list1&&list2)
        {
        if(list1->val <= list2->val)
            {   
                p =list1;
                list1 = list1->next;
            }
        else 
        {
                 p =list2;
                list2 = list2->next;
        }
        q=p;
        }
        else if(!(list1||list2))
        {
            return list1;
        }
        else 
        {
            if(list1)return list1;
            else return list2;
        }

        while(list1&&list2)
        {
            if(list1->val <= list2->val)
            {   
                p->next =list1;
                p=p->next;
                list1 = list1->next;
            }
            else
            {
                 p->next =list2;
                 p=p->next;
                list2 = list2->next;
            }
     
        }
        if(list1) p->next =list1;
        else  p->next =list2;
        return q;
    }
};
