class Solution {
public:
    bool isPalindrome(ListNode* head) {
        vector<int> m;
        while(head)
        {
            m.push_back(head->val);
            head=head->next;
        }
        int num=m.size();
        while(num)
        {
            if(m[num-1]!=m[m.size()-num]) return false;
            num--;
        }
        return true;
    }
};
